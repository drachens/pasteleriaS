	<footer>
		<div class="media" align="">
			<br>
			<h4 id="sg">Siguenos en: </h4>
			<p id="rrss"><a id="one" href="e503.html">Facebook</a>  <a id="two" href="e503.html">Instagram</a>  <a id="three" href="e503.html">Twitter</a></p>
		</div>
		<center style="margin-top:100px;margin-bottom: 50px">&#169; 2020 Todos los derechos reservados.</center>
	</footer>
</body>
</html>