	<?php 
		include_once("header.php");
	 ?>
	 <header>
	 	<title>¿Quienes somos?</title>
	 </header>
	<br>
	<nav class="Categorias">
		<ul>
			<li class="ref"><a class="ref1" href="index.php">Inicio</a></li>
			<li><a href="informacion.php">¿Quienes somos?</a></li>
		</ul>
	<br>
	<h1 class="adv" style="color:#c00505">Quedate en casa, cuidate y cuida a los demás.</h1>
	</nav>
	<div class="Qs_out">
		<div class="Qs_img">
			<img src="https://i.pinimg.com/originals/b7/91/ca/b791caa83f0765ebd0522f0449284746.jpg">
		</div>
		<div class="prph">
			<p id="P1prph">¿Quienes Somos?</p>
			<p id="P2prph">Para contarles como inició todo esto debemos remontarnos al año 1864, donde en un pequeño pueblo localizado en la Region del Maule vivió un hombre que cocinó uno de los pasteles mas importantes para la cultura de la localidad. Hoy en día este pastel es consumido por todos los chilenos a lo largo del país e incluso se comercializa al exterior. <br><br> Piñufle, así fue como Juan Nieves llamó a su icónico pastel en honor a su abuela, que fue quien le había enseñado todo lo que hasta ese momento sabía de pastelería. </p>
		</div>
		<div class = "prph2">
			<p>Esta receta se ha pasado generación tras generación por la familia de los Nieves, hasta que hace unos años como familia decidimos volver a producir Piñufles para la comunidad. Nuestros vecinos, quienes fueron los primeros en probar este pastel nos incentivaron a expandirnos para que mas personas pudieran comer Piñufles. Es por esto que hace 3 años que comenzamos con este proyecto, en donde ademas de vender nuestro característico pastel hemos expandido nuestra variedad de productos para así poder ofrecer una gran variedad de pasteles a nuestros consumidores.</p>
		</div>		
	</div>
	 <?php
		include_once("footer.php")
	?>

	 